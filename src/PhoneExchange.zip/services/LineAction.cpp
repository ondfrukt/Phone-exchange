// Innehåller logik som körs när linjer ändrar tillstånd
